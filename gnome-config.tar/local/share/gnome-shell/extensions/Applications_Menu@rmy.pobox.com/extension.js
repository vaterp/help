// Copyright (C) 2011-2013 R M Yorston
// Licence: GPLv2+

const Clutter = imports.gi.Clutter;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const GMenu = imports.gi.GMenu;
const Lang = imports.lang;
const Shell = imports.gi.Shell;
const St = imports.gi.St;

const Layout = imports.ui.layout;
const Main = imports.ui.main;
const ModalDialog = imports.ui.modalDialog;
const Panel = imports.ui.panel;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;

const _ = imports.gettext.domain('gnome-shell').gettext;
const _f = imports.gettext.domain('frippery-applications-menu').gettext;

const SETTINGS_FILE = ".frippery_appm";
const TLC_MASK =   1<<0;
const ICON_MASK =  1<<1;
const LABEL_MASK = 1<<2;
const V2_MASK =    1<<3;
const MAX_MASK =  (1<<4)-1;
const DEFAULT_MASK = TLC_MASK|ICON_MASK|LABEL_MASK|V2_MASK;

const ApplicationMenuItem = new Lang.Class({
    Name: 'ApplicationMenuItem',
    Extends: PopupMenu.PopupBaseMenuItem,

    _init: function(app, params) {
        PopupMenu.PopupBaseMenuItem.prototype._init.call(this, params);

        let box = new St.BoxLayout({ name: 'applicationMenuBox',
                                     style_class: 'applications-menu-item-box'});
        this.actor.add_child(box);

        let icon = app.create_icon_texture(24);
        box.add(icon, { x_fill: false, y_fill: false });

        let name = app.get_name();

        let matches = /^(OpenJDK Policy Tool) (.*)/.exec(name);
        if ( matches && matches.length == 3 ) {
            name = matches[1] + "\n" + matches[2];
        }

        matches = /^(OpenJDK Monitoring & Management Console) (.*)/.exec(name);
        if ( matches && matches.length == 3 ) {
            name = "OpenJDK Console\n" + matches[2];
        }

        let label = new St.Label({ text: name });
        box.add(label);

        this.app = app;

        this.connect('activate', Lang.bind(this, function() {
            let id = this.app.get_id();
            let app = Shell.AppSystem.get_default().lookup_app(id);
            app.open_new_window(-1);
        }));
    }
});

const ToggleSwitch = new Lang.Class({
    Name: 'ToggleSwitch',
    Extends: PopupMenu.Switch,

    _init: function(state) {
        PopupMenu.Switch.prototype._init.call(this, state);

        this.actor.can_focus = true;
        this.actor.reactive = true;
        this.actor.add_style_class_name("applications-menu-toggle-switch");

        this.actor.connect('button-release-event',
                Lang.bind(this, this._onButtonReleaseEvent));
        this.actor.connect('key-press-event',
                Lang.bind(this, this._onKeyPressEvent));
        this.actor.connect('key-focus-in',
                Lang.bind(this, this._onKeyFocusIn));
        this.actor.connect('key-focus-out',
                Lang.bind(this, this._onKeyFocusOut));
    },

    _onButtonReleaseEvent: function(actor, event) {
        this.toggle();
        return true;
    },

    _onKeyPressEvent: function(actor, event) {
        let symbol = event.get_key_symbol();

        if (symbol == Clutter.KEY_space || symbol == Clutter.KEY_Return) {
            this.toggle();
            return true;
        }

        return false;
    },

    _onKeyFocusIn: function(actor) {
        actor.add_style_pseudo_class('active');
    },

    _onKeyFocusOut: function(actor) {
        actor.remove_style_pseudo_class('active');
    },

    getState: function() {
        return this.state;
    }
});

const ShowHideSwitch = new Lang.Class({
    Name: 'ShowHideSwitch',
    Extends: ToggleSwitch,

    _init: function(item, state) {
        ToggleSwitch.prototype._init.call(this, state);

        this.item = item;
    },

    toggle: function() {
        ToggleSwitch.prototype.toggle.call(this);

        if ( this.state ) {
            this.item.show();
        }
        else {
            this.item.hide();
        }
    }
});

const ApplicationsMenuDialog = new Lang.Class({
    Name: 'ApplicationsMenuDialog',
    Extends: ModalDialog.ModalDialog,

    _init: function(button) {
        ModalDialog.ModalDialog.prototype._init.call(this,
                    { styleClass: 'applications-menu-dialog' });

        this.button = button;

        let table = new St.Table({homogeneous: false, reactive: true,
                              styleClass: 'applications-menu-dialog-table'});
        this.contentLayout.add(table, { y_align: St.Align.START });

        let label = new St.Label(
                        { style_class: 'applications-menu-dialog-label',
                          text: _f('Icon') });
        table.add(label, { row: 0, col: 0 });

        this.iconSwitch = new ShowHideSwitch(button._iconBox, true);
        table.add(this.iconSwitch.actor, { row: 0, col: 1 });

        label = new St.Label(
                        { style_class: 'applications-menu-dialog-label',
                          text: _f('Text') });
        table.add(label, { row: 1, col: 0 });

        this.labelSwitch = new ShowHideSwitch(button._label, true);
        table.add(this.labelSwitch.actor, { row: 1, col: 1 });

        label = new St.Label({ style_class: 'applications-menu-dialog-label',
                        text: _f('Hot corner') });
        table.add(label, { row: 2, col: 0 });

        this.tlcSwitch = new ToggleSwitch(true);
        this.tlcSwitch.toggle = Lang.bind(this.tlcSwitch, function() {
                PopupMenu.Switch.prototype.toggle.call(this);
                Main.layoutManager._setHotCornerState(this.getState());
            });
        table.add(this.tlcSwitch.actor, { row: 2, col: 1 });

        let buttons = [{ action: Lang.bind(this, this.close),
                         label:  _f("Close"),
                         default: true }];

        this.setButtons(buttons);

        this._buttonKeys[Clutter.Escape] = this._buttonKeys[Clutter.Return];
    },

    open: function() {
        let settings = this.button.getSettings();

        let state = (settings&ICON_MASK) != 0;
        this.iconSwitch.setToggleState(state);

        state = (settings&LABEL_MASK) != 0;
        this.labelSwitch.setToggleState(state);

        state = (settings&TLC_MASK) != 0;
        this.tlcSwitch.setToggleState(state);

        ModalDialog.ModalDialog.prototype.open.call(this,
                global.get_current_time());
    },

    close: function() {
        let settings = V2_MASK;
        if ( this.iconSwitch.getState() ) {
            settings |= ICON_MASK;
        }

        if ( this.labelSwitch.getState() ) {
            settings |= LABEL_MASK;
        }

        if ( this.tlcSwitch.getState() ) {
            settings |= TLC_MASK;
        }

        if ( settings != this.button.getSettings() ) {
            this.button.setSettings(settings);
            let settingsFilePath = GLib.get_home_dir() + '/' + SETTINGS_FILE;
            let settingsFile = Gio.file_new_for_path(settingsFilePath);
            settingsFile.replace_contents(settings+'\n', null, false, 0, null);
        }

        ModalDialog.ModalDialog.prototype.close.call(this,
                global.get_current_time());
    }
});

const ApplicationsMenuButton = new Lang.Class({
    Name: 'ApplicationsMenuButton',
    Extends: PanelMenu.Button,

    _init: function() {
        this.parent(1.0, null, false);

        this.settings = DEFAULT_MASK;

        let settingsFilePath = GLib.get_home_dir() + '/' + SETTINGS_FILE;
        let settingsFile = Gio.file_new_for_path(settingsFilePath);
        if ( settingsFile.query_exists(null) ) {
            let [flag, str] = settingsFile.load_contents(null);
            if ( flag ) {
                let iset = parseInt(str);
                if ( !isNaN(iset) && iset >= 0 && iset <= MAX_MASK ) {
                    this.settings = iset;

                    // version 1 settings didn't include label
                    if ( (this.settings&V2_MASK) == 0 ) {
                        this.settings |= LABEL_MASK;
                    }
                }
            }
        }

        this._box = new St.BoxLayout();

        this._iconBox = new St.Bin();
        this._box.add(this._iconBox, { y_align: St.Align.MIDDLE, y_fill: false });

        let logo = new St.Icon({ icon_name: 'start-here',
                                 style_class: 'applications-menu-button-icon'});
        this._iconBox.child = logo;

        let label = new St.Label({ text: " " });
        this._box.add(label, { y_align: St.Align.MIDDLE, y_fill: false });

        this._label = new St.Label({ text: _("Applications") });
        this._box.add(this._label, { y_align: St.Align.MIDDLE, y_fill: false });
        this.actor.add_actor(this._box);

        if ( (this.settings&ICON_MASK) == 0 ) {
            this._iconBox.hide();
        }

        if ( (this.settings&LABEL_MASK) == 0 ) {
            this._label.hide();
        }

        let state = (this.settings&TLC_MASK) != 0;
        Main.layoutManager._setHotCornerState(state);

        this.actor.connect('destroy', Lang.bind(this, this._onDestroy));

        this._appSystem = Shell.AppSystem.get_default();
        this._installChangedId = this._appSystem.connect('installed-changed',
                Lang.bind(this, this._rebuildMenu));

        // Since the hot corner uses stage coordinates, Clutter won't
        // queue relayouts for us when the panel moves. Queue a relayout
        // when that happens.  Stolen from apps-menu extension.
        this._panelBoxChangedId = Main.layoutManager.connect(
                'panel-box-changed', Lang.bind(this, function() {
                                        container.queue_relayout();
                                    }));

        this._buildMenu();

        this.actor.connect('button-release-event',
                    Lang.bind(this, this._showDialog));
    },

    _onButtonPress: function(actor, event) {
        if ( event.get_button() == 3 ) {
            return true;
        }

        if ( (this.settings&ICON_MASK) == 0 &&
                (this.settings&LABEL_MASK) == 0 ) {
            return true;
        }

        return PanelMenu.Button.prototype._onButtonPress.call(this, actor, event);
    },

    _onDestroy: function() {
        if ( this._installChangedId != 0 ) {
            this._appSystem.disconnect(this._installChangedId);
            this._installChangedId = 0;
        }

        if ( this._panelBoxChangedId != 0 ) {
            Main.layoutManager.disconnect(this._panelBoxChangedId);
            this._panelBoxChangedId = 0;
        }
    },

    // Stolen from appDisplay.js and apps-menu extension
    _loadCategory: function(dir, appList) {
        let iter = dir.iter();
        let nextType;
        while ((nextType = iter.next()) != GMenu.TreeItemType.INVALID) {
            if (nextType == GMenu.TreeItemType.ENTRY) {
                let entry = iter.get_entry();
                let appInfo = entry.get_app_info();
                let app = this._appSystem.lookup_app(entry.get_desktop_file_id());
                if (appInfo.should_show())
                    appList.push(app);
            } else if (nextType == GMenu.TreeItemType.DIRECTORY) {
                var itemDir = iter.get_directory();
                if (!itemDir.get_is_nodisplay())
                    this._loadCategory(itemDir, appList);
            }
        }
    },

    _buildSections: function() {
        // Stolen from appDisplay.js and apps-menu extension
        var tree = new GMenu.Tree({menu_basename: 'applications.menu'});
        tree.load_sync();
        var root = tree.get_root_directory();

        var iter = root.iter();
        var nextType;

        var sections = [];
        while ((nextType = iter.next()) != GMenu.TreeItemType.INVALID) {
            if (nextType == GMenu.TreeItemType.DIRECTORY) {
                var dir = iter.get_directory();
                if (dir.get_is_nodisplay())
                    continue;
                var appList = [];
                this._loadCategory(dir, appList);
                if ( appList.length != 0 ) {
                    sections.push({ name: dir.get_name(),
                                    apps: appList });
                }
            }
        }

        return sections;
    },

    _buildMenu: function() {
        let sections = this._buildSections();
        for ( let i=0; i<sections.length; ++i ) {
            let section = sections[i];
            let submenu = new PopupMenu.PopupSubMenuMenuItem(section.name);
            this.menu.addMenuItem(submenu);

            for ( let j=0; j<section.apps.length; ++j ) {
                let app = section.apps[j];
                let menuItem = new ApplicationMenuItem(app);

                submenu.menu.addMenuItem(menuItem, j);
            }
    }
    },

    _rebuildMenu: function() {
        this.menu.removeAll();
        this._buildMenu();
    },

    _showDialog: function(actor, event) {
        if ( event.get_button() == 3 ) {
            let applicationsMenuDialog = new ApplicationsMenuDialog(this);
            applicationsMenuDialog.open();
            return true;
        }
        return false;
    },

    getSettings: function() {
        return this.settings;
    },

    setSettings: function(settings) {
        this.settings = settings;
    }
});

const ApplicationsMenuExtension = new Lang.Class({
    Name: 'ApplicationsMenuExtension',

    _init: function(extensionMeta) {
        let localePath = extensionMeta.path + '/locale';
        imports.gettext.bindtextdomain('frippery-applications-menu', localePath);
    },

    enable: function() {
        let mode = Main.sessionMode.currentMode;
        if ( mode == 'classic' ) {
            return;
        }

        // inject a flag into the hot corner update function so we can
        // prevent updates when we've disabled the hot corner
        Layout.LayoutManager.prototype._origUpdateHotCorners =
                Layout.LayoutManager.prototype._updateHotCorners;
        Layout.LayoutManager.prototype._updateHotCorners = function() {
           if ( this._hotCornersEnabled ) {
               this._origUpdateHotCorners();
           }
        };

        Layout.LayoutManager.prototype._setHotCornerState = function(state) {
            // only do work if state is changing
            if ( state && !this._hotCornersEnabled ) {
                this._origUpdateHotCorners();
            }
            else if ( !state && this._hotCornersEnabled ) {
                for (let i = 0; i < this.hotCorners.length; i++) {
                    this.hotCorners[i].destroy();
                }
                this.hotCorners = [];
            }
            this._hotCornersEnabled = state;
        };
        Main.layoutManager._hotCornersEnabled = true;

        this.activitiesButton = Main.panel.statusArea['activities'];
        if ( this.activitiesButton ) {
            this.activitiesButton.container.hide();
        }

        this.applicationsButton = new ApplicationsMenuButton();
        Main.panel.addToStatusArea('frippery-apps', this.applicationsButton,
                0, 'left');

        Main.wm.setCustomKeybindingHandler('panel-main-menu',
                                   Shell.KeyBindingMode.NORMAL |
                                   Shell.KeyBindingMode.OVERVIEW,
                                   function() {
                                       this.applicationsButton.menu.toggle();
                                   });
    },

    disable: function() {
        let mode = Main.sessionMode.currentMode;
        if ( mode == 'classic' ) {
            return;
        }

        Layout.LayoutManager.prototype._updateHotCorners =
                Layout.LayoutManager.prototype._origUpdateHotCorners;
        delete Layout.LayoutManager.prototype._origUpdateHotCorners;
        delete Layout.LayoutManager.prototype._disableHotCorners;
        delete Main.layoutManager._hotCornersEnabled;
        Main.layoutManager._updateHotCorners();

        Main.panel.menuManager.removeMenu(this.applicationsButton.menu);
        this.applicationsButton.destroy();

        if ( this.activitiesButton ) {
            this.activitiesButton.container.show();

            Main.wm.setCustomKeybindingHandler('panel-main-menu',
                               Shell.KeyBindingMode.NORMAL |
                               Shell.KeyBindingMode.OVERVIEW,
                               Main.sessionMode.hasOverview ?
                               Lang.bind(Main.overview, Main.overview.toggle) :
                               null);
        }
    }
});

function init(extensionMeta) {
    return new ApplicationsMenuExtension(extensionMeta);
}
