/* constants and stuff */

const SETTINGS_USE_KEYPAD = "use-kp-keys";
const SETTINGS_USE_NUMS = "use-num-keys";
const SETTINGS_USE_NW = "use-nw";
const SETTINGS_USE_NKP = "use-kp-nw";
const SETTINGS_CLOSE_OVERVIEW = "close-overview";
