#!/bin/bash

while true
do
	date  >> output.txt
	./txlinecard.getstats >>  output.txt
	sleep 10
done
